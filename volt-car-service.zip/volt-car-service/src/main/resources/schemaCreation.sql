-- Install mysql server on local
   brew install mysql
   
-- Connect to local MySQL server with root user 
   mysql -u root -p

-- Create DataBase
   CREATE DATABASE `volt`;

-- Create DB User
   CREATE USER 'voltusr'@'localhost' IDENTIFIED BY 'shee12';
   GRANT ALL ON *.* TO 'voltusr'@'localhost';

-- Update application.properties with user details if changed

-- Create Schema
USE volt;
CREATE TABLE `service_operator` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `customer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `appointment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `start` datetime(6) DEFAULT NULL,
  `end` datetime(6) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `customer_id` bigint NOT NULL,
  `service_operator_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_customer` (`customer_id`),
  KEY `FK_operator` (`service_operator_id`),
  CONSTRAINT `FK_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `FK_operator` FOREIGN KEY (`service_operator_id`) REFERENCES `service_operator` (`id`),
  CONSTRAINT `appointment_chk_1` CHECK ((`status` between 0 and 1))
);

-- Sample Data Population
INSERT INTO `service_operator`(`name`) VALUES
('Service Operator A'),
('Service Operator B'),
('Service Operator C');

INSERT INTO `customer`(`name`) VALUES
('C1');

INSERT INTO `appointment`(`start`, `end`, `status`, `customer_id`, `service_operator_id`) VALUES
('2023-08-06T12:00','2023-08-06T13:00',0,1,1);
