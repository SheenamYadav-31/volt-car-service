package com.volt.voltcarservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.volt.voltcarservice.model.ServiceOperator;
import com.volt.voltcarservice.dao.ServiceOperatorRepo;

@RestController
@RequestMapping("/carservice")
public class ServiceOperatorController {
	
	@Autowired
	private ServiceOperatorRepo repo;
	    
	   
	@GetMapping("/operators")
	public List<ServiceOperator> getAllOperators() {
		return repo.findAll();
	}
	
	@GetMapping("/operator/{id}")
	public ServiceOperator getOperator(@PathVariable Long id) {
		Optional<ServiceOperator> response = repo.findById(id);
		return response.isPresent() ? response.get() : new ServiceOperator(); // TODO throw error
	}
	
	@PostMapping("/operator")
	public ServiceOperator saveOperator(@RequestBody ServiceOperator operator) {
		return repo.save(operator);
	}
	
	@PutMapping("/operator")
	public ServiceOperator updateOperator(@RequestBody ServiceOperator updatedOperator) { // TODO : handle exception
		return repo.findById(updatedOperator.getId())
			      .map(operator -> {
			    	  operator.setName(updatedOperator.getName());
			        return repo.save(operator);
			      })
			      .orElseGet(() -> {
			        return repo.save(updatedOperator);
			      });
	}
	
	@DeleteMapping("/operator/{id}")
	void deleteOperator(@PathVariable Long id) {
		repo.deleteById(id);
	}
}
