package com.volt.voltcarservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.volt.voltcarservice.dao.CustomerRepo;
import com.volt.voltcarservice.model.Customer;

@RestController
@RequestMapping("/carservice")
public class CustomerController {
	
	@Autowired
	private CustomerRepo customerRepo;
	    
	   
	@GetMapping("/customers")
	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}
	
	@GetMapping("/customer/{id}")
	public Customer getCustomer(@PathVariable Long id) {
		Optional<Customer> response = customerRepo.findById(id);
		return response.isPresent() ? response.get() : new Customer(); // TODO throw error
	}
	
	@PostMapping("/customer")
	public Customer saveCustomer(@RequestBody Customer customer) {
		return customerRepo.save(customer);
	}
	
	@PutMapping("/customer")
	public Customer updateCustomer(@RequestBody Customer updatedCustomer) { // TODO : handle exception
		return customerRepo.findById(updatedCustomer.getId())
			      .map(customer -> {
			    	  customer.setName(updatedCustomer.getName());
			        return customerRepo.save(customer);
			      })
			      .orElseGet(() -> {
			        return customerRepo.save(updatedCustomer);
			      });
	}
	
	@DeleteMapping("/customer/{id}")
	void deleteCustomer(@PathVariable Long id) {
		customerRepo.deleteById(id);
	}
}


