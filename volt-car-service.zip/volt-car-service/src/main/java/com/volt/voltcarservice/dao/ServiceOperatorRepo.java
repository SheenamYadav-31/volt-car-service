package com.volt.voltcarservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.volt.voltcarservice.model.ServiceOperator;

public interface ServiceOperatorRepo extends JpaRepository<ServiceOperator, Long> {

}
