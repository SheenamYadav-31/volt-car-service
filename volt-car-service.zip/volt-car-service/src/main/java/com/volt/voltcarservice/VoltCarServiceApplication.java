package com.volt.voltcarservice;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.volt.voltcarservice.dao.ServiceOperatorRepo;
import com.volt.voltcarservice.model.ServiceOperator;

@SpringBootApplication
public class VoltCarServiceApplication {
	
	@Autowired
	private ServiceOperatorRepo serviceOperatorRepo;

	public static void main(String[] args) {
		SpringApplication.run(VoltCarServiceApplication.class, args);
	}
	
	// TODO : move to config
	@Bean
	InitializingBean sendDatabase() {
	    return () -> {
	    	ServiceOperator s1 = new ServiceOperator();
	    	s1.setName("Service Operator A");
	    	ServiceOperator s2 = new ServiceOperator();
	    	s2.setName("Service Operator B");
	    	ServiceOperator s3 = new ServiceOperator();
	    	s3.setName("Service Operator C");
	    	serviceOperatorRepo.save(s1);
	    	serviceOperatorRepo.save(s2);
	    	serviceOperatorRepo.save(s3);
	      };
	   }

}
