package com.volt.voltcarservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.volt.voltcarservice.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Long> {
}
