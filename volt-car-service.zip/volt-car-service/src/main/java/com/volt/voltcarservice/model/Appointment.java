package com.volt.voltcarservice.model;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import enums.Status;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Appointment {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
	 
	 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	 LocalDateTime start;
	 
	 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
	 LocalDateTime end;
	 
	 Status status;
	 
	 @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	 @JoinColumn(name = "customer_id", referencedColumnName = "id", nullable=false)
	 Customer customer;
	 
	 @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	 @JoinColumn(name = "service_operator_id", referencedColumnName = "id", nullable=false)
	 ServiceOperator serviceOperator;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getStart() {
		return start;
	}

	public void setStart(LocalDateTime start) {
		this.start = start;
	}

	public LocalDateTime getEnd() {
		return end;
	}

	public void setEnd(LocalDateTime end) {
		this.end = end;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public ServiceOperator getServiceOperator() {
		return serviceOperator;
	}

	public void setServiceOperator(ServiceOperator serviceOperator) {
		this.serviceOperator = serviceOperator;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", start=" + start + ", end=" + end + ", customer=" + customer
				+ ", serviceOperator=" + serviceOperator + "]";
	}
	 
}
