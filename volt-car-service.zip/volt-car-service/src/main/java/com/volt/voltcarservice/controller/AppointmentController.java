package com.volt.voltcarservice.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.volt.voltcarservice.dao.AppointmentRepo;
import com.volt.voltcarservice.model.Appointment;
import com.volt.voltcarservice.model.Slot;

import enums.Status;

@RestController
@RequestMapping("/carservice/appointment")
public class AppointmentController {
	
	@Autowired
	private AppointmentRepo repo;
	
	@PostMapping("")
	public Appointment saveAppointment(@RequestBody Appointment appointment) {
		// setting Scheduled status and end time before saving appointment
		appointment.setStatus(Status.Scheduled);
		appointment.setEnd(appointment.getStart().plusHours(1L));
		return repo.save(appointment);
	}
	
	@PutMapping("")
	public Appointment updateAppointment(@RequestBody Appointment updatedAppointment) { // TODO : handle exception
		return repo.findById(updatedAppointment.getId())
			      .map(appointment -> {
			    	  appointment.setStart(updatedAppointment.getStart());
			    	  appointment.setEnd(updatedAppointment.getEnd());
			    	  appointment.setCustomer(updatedAppointment.getCustomer());
			    	  appointment.setServiceOperator(updatedAppointment.getServiceOperator());
			        return repo.save(appointment);
			      })
			      .orElseGet(() -> {
			        return repo.save(updatedAppointment);
			      });
	}
	
	@DeleteMapping("/{id}")
	void deleteAppointment(@PathVariable Long id) {
		repo.deleteById(id);
	}
	 
	@GetMapping("/customer/{customerId}")
	public List<Appointment> getAllAppointmentsByCustomer(@PathVariable Long customerId) {
		return repo.findByStatusAndCustomer_Id(Status.Scheduled, customerId);
	}
	
	@GetMapping("/operator/{operatorId}")
	public List<Appointment> getAllAppointmentsByOperator(@PathVariable("operatorId") Long operatorId) {
		List<Appointment> appointments = repo.findByStatusAndServiceOperator_Id(Status.Scheduled, operatorId);
		appointments.sort((s1, s2) -> s1.getStart().compareTo(s2.getStart()));
		return appointments;
	}
	
	@GetMapping("/slots/{operatorId}/{start}/{end}")
	public List<Slot> getAvailableSlotsByOperator(@PathVariable("operatorId") Long operatorId, 
			@PathVariable("start") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start, 
			@PathVariable("end") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end
			) {
		List<Appointment> bookedAppointments = repo.findByStartGreaterThanEqualAndEndLessThanEqualAndServiceOperator_IdOrderByStart(start, end, operatorId);
		Set<LocalDateTime> allSlots = generateSlots(start, end);
		List<Slot> availableSlots = new ArrayList<>();
		
		LocalDateTime curr = start;
		
		for(Appointment appointment : bookedAppointments){
			if(curr.isBefore(appointment.getStart())) {
				availableSlots.add(new Slot(curr, appointment.getStart()));
			}
			curr = appointment.getEnd();
		}
		
		if(curr.isBefore(end)) {
			availableSlots.add(new Slot(curr, end));
		}
		
		availableSlots.sort((s1, s2) -> s1.getStart().compareTo(s2.getStart()));
		
		return availableSlots;
	}
	
	private Set<LocalDateTime> generateSlots(LocalDateTime start, LocalDateTime end) {
		Set<LocalDateTime> slots = new HashSet<>();
		if (start.isBefore(end)){
			LocalDateTime current = start;
			while(current.isBefore(end)) {
				slots.add(current);
				current = current.plusHours(1L);
			}
		} else {
			// TODO : throw exception on invalid on start or end
			return slots;
		}
		return slots;
	}
}
