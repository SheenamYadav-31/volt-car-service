package com.volt.voltcarservice.dao;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.volt.voltcarservice.model.Appointment;

import enums.Status;

public interface AppointmentRepo extends JpaRepository<Appointment, Long> {
	
	List<Appointment> findByStatusAndCustomer_Id(Status status, Long id);
	
	List<Appointment> findByStatusAndServiceOperator_Id(Status status, Long id);
	
	List<Appointment> findByStartGreaterThanEqualAndEndLessThanEqualAndServiceOperator_IdOrderByStart(LocalDateTime start, LocalDateTime end, Long id);

}
