package com.volt.voltcarservice.configuration;

public class LoadData {

}
