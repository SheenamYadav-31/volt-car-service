package enums;

public enum Status {
	Scheduled,
	Cancelled
}
